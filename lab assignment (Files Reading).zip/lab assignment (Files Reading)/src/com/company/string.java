package com.company;

public class string {
}
